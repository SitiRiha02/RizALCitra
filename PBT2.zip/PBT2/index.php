<!DOCTYPE html>
<html>
	<head>
		<title>RizALCitra Software House</title>
		<link rel="stylesheet" type="text/css" href="css/index.css">
	</head>
	
<body>
	<div id="header">
		<div class="head-view">
			<ul>
				<li><b>Cosmetic Sale System</b></li>
				<li><a href="signin.php" title="Sign in"><button class="btn-sign-in" value="Sign in">Sign in</button></a></li>
				<li><a href="signup.php" title="Sign up"><button class="btn-sign-up" value="Sign up">Sign up</button></a></li>
			</ul>
		</div>
	</div>
	<div id="content">
		
	</div>
</body>
</html>