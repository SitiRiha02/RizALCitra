<?php
mysql_select_db('pbt2',mysql_connect('localhost','root',''))or die(mysql_error());
?>
